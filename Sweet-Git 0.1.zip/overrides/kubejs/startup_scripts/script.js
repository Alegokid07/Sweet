// priority: 0

console.info('Hello, World! (You will only see this line once in console, during startup)')

onEvent('item.registry', event => {
	// Register new items here
	// event.create('example_item').displayName('Example Item')
})

onEvent('block.registry', event => {
	// Register new blocks here
	// event.create('example_block').material('wood').hardness(1.0).displayName('Example Block')
})

onEvent('item.registry', event => {
  event.create('fizzied_coal').displayName('Fizzied Coal')
  event.create('raw_carbon').displayName('Raw Carbon')
  event.create('carbon').displayName('Carbon')
  event.create('oxidised_carbon').displayName('Oxidised Carbon')
  event.create('crystallised_sugar').displayName('Crystallised Sugar')
  })
  onEvent('fluid.registry', event => {
  event.create('carbon_dioxide').displayName('Carbon Dioxide').textureStill('kubejs:block/carbon_dioxide_still').textureFlowing('kubejs:block/carbon_dioxide_flow').bucketColor(0xffffff)
  event.create('diet_coke').displayName('Diet Coke').textureStill('kubejs:block/diet_coke_still').textureFlowing('kubejs:block/diet_coke_flow').bucketColor(0x654321)
  event.create('cola').displayName('Cola').textureStill('kubejs:block/cola_still').textureFlowing('kubejs:block/cola_flow').bucketColor(0xa0522d)
  event.create('caramel').displayName('Caramel').textureStill('kubejs:block/caramel_still').textureFlowing('kubejs:block/caramel_flow').bucketColor(0xd2691e)
  event.create('carbonated_water').displayName('Carbonated Water').textureStill('kubejs:block/sparkling_water_still').textureFlowing('kubejs:block/sparkling_water_flow').bucketColor(0x6699cc)
})